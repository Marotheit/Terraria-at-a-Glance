$(document).ready(function(){
	$("#relevant_build").load("build%20resources/New%20Build.txt");
});